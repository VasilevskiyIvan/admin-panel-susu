import { Link } from 'react-router-dom'
import './MenuSection.css'
import vite from '/avatar.png'

const MenuSection = () => {
    return (
        <div className="menu-section">
            <header className="menu-header">
                <img src={vite} alt="Аватарка"/>
                <h1>Васильева В.В.</h1>
            </header>
            <div className="button-container">
                <p>Меню: </p>
                <Link to="/" className="menu-button">
                    главная
                </Link>
                <Link to="/blocks/new" className="menu-button">
                    добавить блок
                </Link>
                <Link to="/blocks/select" className="menu-button">
                    редактировать блок
                </Link>
                <Link to="/broadcast" className="menu-button">
                    разослать сообщение
                </Link>
                <Link to="/broadcast" className="exit-button">
                    выйти
                </Link>
            </div>
        </div>
    )
}

export default MenuSection